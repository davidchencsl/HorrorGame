#pragma once

enum DazCharacterType
{
	Genesis1,
	Genesis3Male,
	Genesis3Female,
	Genesis8Male,
	Genesis8Female,
	Unknown
};
