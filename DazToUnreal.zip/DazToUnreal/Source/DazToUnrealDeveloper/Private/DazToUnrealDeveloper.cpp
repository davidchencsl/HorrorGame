#include "DazToUnrealDeveloper.h"

#define LOCTEXT_NAMESPACE "FDazToUnrealDeveloperModule"

void FDazToUnrealDeveloperModule::StartupModule()
{

}

void FDazToUnrealDeveloperModule::ShutdownModule()
{

}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FDazToUnrealDeveloperModule, DazToUnrealDeveloper)